# minecraft-discord-bot
minecraft sunucuları için discord botu

Merhabalar, 
bu bot minecraft Sunucularınız için basit ama işe yarayan hoşunuza gidecek bir bot.
Tüm ayarlar config.js içinde bulunmakta config.js düzenleyerek hazır hale getirebilirsiniz

Not: Sesli kanalda online gösterme kısmı Discord'un izin verdiği şekilde çalışmakta yani bir sınırı var kısa sürede çok sayıda düzenleme yapılamıyor kanal isminde bu süre 10 dakika gibi bir süre

# Kurulum
  - **config.js** dosyasını kendimize göre düzenliyoruz
  - **setup.bat** dosyasını çalıştırıyoruz
  - **start.bat** ile bot tamamen aktif oluyor

Bulduğunuz Hata&Buglar için Discord: https://discord.gg/wvYujGGEfp
