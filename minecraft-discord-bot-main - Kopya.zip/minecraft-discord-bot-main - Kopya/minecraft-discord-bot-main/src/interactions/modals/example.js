module.exports =  {
	data: {
		name: "example",
        modalId: "example"
	},

	async execute(interaction) {
        console.log("this is a modal");
    }
};
