const settings = require("../../../app.js")

module.exports =  {
	data: {
		name: "name",
        buttonId: "id"
	},

	async execute(interaction) {
        console.log("this is a button");
    }}