module.exports =  {
	data: {
		name: "example",
    selectMenuId: "example"
	},

	async execute(interaction) {
        console.log("this is a select menu");
    }
};
