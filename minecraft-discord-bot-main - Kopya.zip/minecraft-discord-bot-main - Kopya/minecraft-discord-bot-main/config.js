﻿const config = {
    bot : {
        slashCommands: "global", // global veya sunucuIDsi yazın - slash olmayacaksa undefined yapın
	    token: "NzI0OTI4MTU4NzUwNzM2NDQ1.Geoj8h.PUz1ju6ntKlH9Jb-RUJmXcy9zCzBOnXXuVohjg", //Bot Tokeniniz
	    prefix: ["."], //komut ön eki
        id: "724928158750736445" //bot idsi
   },
    sunucu : {
	    ip: "oyna.rusimc.xyz", //sunucu adresi
        isim: "RusiMC" //sunucu ismi
   },
    kanal : {
	    aktif: true, //sesli kanalda online gösterme aktif mi(true) olsun kapalı mı(false)
	    id: "1050789348712402945", // sunucu online sayısının gözükeceği kanal (ses kanalı)
	    yazi: "• Aktif: {online}/{maxonline}" // kanalda gözükecek yazı
   },
    durum : {
	    mesaj: "{online} Kişi Sunucumuzda" // bot durumunda online sayısı 
   },
    ticket : {
        
        parentOpened: "", //destek talep kanallarının açılacağı kategorinin idsi
        Category1: "Minecraft Sorunları", //Destek talebi detayı için kategori 3
        Category2: "Bulduğunuz Buglar", //Destek talebi detayı için kategori 2
        Category3: "Şikayetler", //Destek talebi detayı için kategori 3
          
        roleSupport: "", //Destek talebine bakacak kişilere verilecek rolün idsi
            
        logsTicket: "", //Destek taleplerinin loglanacağı kanal
        ticketChannel: "" //Kullanıcıların destek talebi oluşturacağı kanalın idsi
    }
}
module.exports = config
